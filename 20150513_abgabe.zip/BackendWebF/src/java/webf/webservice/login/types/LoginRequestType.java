/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package webf.webservice.login.types;

import webf.webservice.login.LoginRequest;

/**
 *
 * @author PU
 * 
 * Wrapper class for Login Request and Response necessary
 */


public class LoginRequestType {
    
    private LoginRequest loginRequest;

    public LoginRequest getLoginRequest() {
        return loginRequest;
    }

    public void setLoginRequest(LoginRequest loginRequest) {
        this.loginRequest = loginRequest;
    }
    
}
